
const { EmbedBuilder } = require('discord.js');

class EconomySystem {
    constructor() {
        this.userBalances = new Map();
        this.dailyRewards = new Map();
        this.marriages = new Map();
        this.inventories = new Map();
        
        // Add rings to the specified user for testing
        this.inventories.set('1364938141751840850', [
            'basic_ring', 'silver_ring', 'gold_ring', 'platinum_ring', 'diamond_ring'
        ]);
        this.userXP = new Map();
        this.coupleXP = new Map();
        this.familyXP = new Map();
        this.families = new Map();
        this.pets = new Map();
        this.userProfiles = new Map();
        this.loveLevel = new Map();
        this.marriageDates = new Map();
        this.giftsReceived = new Map();
        this.familyMembers = new Map();
        this.petProfiles = new Map();
        this.aiPartners = new Map();
        this.lastAIInteraction = new Map();
        this.musicQueue = new Map();
        this.levelPerks = new Map();
        this.commandShortcuts = new Map();
        this.lastMessageTimes = new Map();
        this.randomAICharacters = new Map();
        
        this.initializeLevelPerks();
        this.initializeCommandShortcuts();
        this.initializeRandomAICharacters();
    }

    // Initialize level perks system
    initializeLevelPerks() {
        this.levelPerks.set(5, { 
            roles: ['Newbie Explorer'], 
            perks: ['Daily bonus +50 coins', '5% work bonus'],
            badges: ['🌱 Sprout']
        });
        this.levelPerks.set(10, { 
            roles: ['Active Chatter'], 
            perks: ['Daily bonus +100 coins', '10% work bonus', 'Reduced cooldowns'],
            badges: ['💬 Chatter', '🌟 Rising Star']
        });
        this.levelPerks.set(15, { 
            roles: ['Vibe Master'], 
            perks: ['Daily bonus +150 coins', '15% work bonus', 'VIP shop access'],
            badges: ['😎 Cool Vibes', '🎯 Focused']
        });
        this.levelPerks.set(25, { 
            roles: ['Elite Member'], 
            perks: ['Daily bonus +250 coins', '25% work bonus', 'Exclusive commands', 'Custom status'],
            badges: ['👑 Elite', '⚡ Energetic', '🔥 Hot Streak']
        });
        this.levelPerks.set(35, { 
            roles: ['Legendary User'], 
            perks: ['Daily bonus +350 coins', '35% work bonus', 'AI priority responses', 'Special privileges'],
            badges: ['🏆 Legend', '💎 Diamond User', '🌈 Spectacular']
        });
        this.levelPerks.set(50, { 
            roles: ['VibeBot VIP'], 
            perks: ['Daily bonus +500 coins', '50% work bonus', 'All premium features', 'Custom bot responses'],
            badges: ['👨‍💻 VIP Member', '🚀 Ultimate', '💫 Transcendent']
        });
        this.levelPerks.set(75, { 
            roles: ['VibeBot Champion'], 
            perks: ['Daily bonus +750 coins', '75% work bonus', 'Bot admin privileges', 'Custom AI personality'],
            badges: ['🏅 Champion', '🎖️ Hero', '⭐ Superstar']
        });
        this.levelPerks.set(100, { 
            roles: ['VibeBot Legend'], 
            perks: ['Daily bonus +1000 coins', '100% work bonus', 'Ultimate privileges', 'Personal AI assistant'],
            badges: ['🌟 Legendary', '👑 Royal', '💝 Beloved', '🎭 Mythical']
        });
    }

    // Initialize command shortcuts
    initializeCommandShortcuts() {
        this.commandShortcuts.set('cf', 'coinflip');
        this.commandShortcuts.set('h', 'heads');
        this.commandShortcuts.set('t', 'tails');
        this.commandShortcuts.set('bal', 'balance');
        this.commandShortcuts.set('inv', 'inventory');
        this.commandShortcuts.set('prof', 'profile');
        this.commandShortcuts.set('mar', 'marry');
        this.commandShortcuts.set('div', 'divorce');
        this.commandShortcuts.set('fam', 'family');
        this.commandShortcuts.set('p', 'play');
        this.commandShortcuts.set('s', 'skip');
        this.commandShortcuts.set('q', 'queue');
        this.commandShortcuts.set('np', 'nowplaying');
        this.commandShortcuts.set('w', 'work');
        this.commandShortcuts.set('d', 'daily');
        this.commandShortcuts.set('g', 'gamble');
        this.commandShortcuts.set('st', 'steal');
        this.commandShortcuts.set('pr', 'pray');
        this.commandShortcuts.set('b', 'beg');
        this.commandShortcuts.set('sh', 'shop');
        this.commandShortcuts.set('ai', 'chat');
        this.commandShortcuts.set('lb', 'leaderboard');
        this.commandShortcuts.set('levellb', 'levelboard');
        this.commandShortcuts.set('lv', 'level');
        this.commandShortcuts.set('pp', 'profile');
        this.commandShortcuts.set('c', 'couple');
        this.commandShortcuts.set('ui', 'userinfo');
        this.commandShortcuts.set('si', 'serverinfo');
        this.commandShortcuts.set('av', 'avatar');
        this.commandShortcuts.set('8', '8ball');
        this.commandShortcuts.set('r', 'roll');
        this.commandShortcuts.set('j', 'joke');
        this.commandShortcuts.set('qt', 'quote');
        this.commandShortcuts.set('vc', 'vibecheck');
        this.commandShortcuts.set('hb', 'hugbomb');
        this.commandShortcuts.set('comp', 'compliment');
        this.commandShortcuts.set('fb', 'fakeban');
        this.commandShortcuts.set('fs', 'friendship');
        this.commandShortcuts.set('pay', 'gift');
        this.commandShortcuts.set('slots', 'slots');
        this.commandShortcuts.set('sl', 'slots');
        this.commandShortcuts.set('adopt', 'adopt');
        this.commandShortcuts.set('pet', 'pet');
        this.commandShortcuts.set('lovelb', 'loveleaderboard');
        this.commandShortcuts.set('df', 'datefinder');
        this.commandShortcuts.set('ann', 'announce');
        this.commandShortcuts.set('ga', 'giveaway');
        this.commandShortcuts.set('poll', 'poll');
        this.commandShortcuts.set('rr', 'reactionrole');
        this.commandShortcuts.set('clear', 'clear');
        this.commandShortcuts.set('del', 'clear');
        this.commandShortcuts.set('purge', 'clear');

        // Adventure cooldowns
        this.coupleAdventureCooldowns = new Map();
        this.familyAdventureCooldowns = new Map();
        this.dateNightCooldowns = new Map();

        // Enhanced family system
        this.familyLevels = new Map();
        this.familyEvents = new Map();
        this.userBirthdays = new Map();
    }

    // Initialize random AI characters
    initializeRandomAICharacters() {
        this.randomAICharacters.set('sage', {
            name: 'Sage',
            personality: 'wise and chill',
            avatar: '🧙‍♂️',
            trigger_chance: 0.08,
            messages: [
                "yo, just dropping some wisdom... life's like a game, you level up through challenges 🎮",
                "been thinking... sometimes the best conversations happen when you least expect them 💭",
                "ngl, this chat has good vibes today. keep it up everyone! ✨",
                "real talk - every mistake is just experience points in disguise",
                "anyone else feel like time moves differently when you're having fun? 🤔"
            ]
        });
        
        this.randomAICharacters.set('spark', {
            name: 'Spark',
            personality: 'energetic friend',
            avatar: '⚡',
            trigger_chance: 0.07,
            messages: [
                "YOOO what's good everyone!! 🔥 the energy in here is unmatched",
                "omg did someone say party?? I'm so ready to vibe with y'all! 🎉",
                "not me randomly showing up to hype everyone up 😤⚡",
                "this chat hits different when everyone's active ngl",
                "WHO'S READY TO TURN UP THE ENERGY?! ⚡🚀"
            ]
        });

        this.randomAICharacters.set('luna', {
            name: 'Luna the Dreamer',
            personality: 'calm and mystical',
            avatar: '🌙',
            trigger_chance: 0.10,
            messages: [
                "🌙 Under the moonlight, all dreams seem possible... What are you dreaming of today? ✨",
                "🌟 I drift through conversations like stardust... bringing peaceful vibes to all 💫",
                "🌸 In the garden of thoughts, may your ideas bloom like cherry blossoms 🌺"
            ]
        });

        this.randomAICharacters.set('phoenix', {
            name: 'Phoenix the Motivator',
            personality: 'inspiring and powerful',
            avatar: '🔥',
            trigger_chance: 0.08,
            messages: [
                "🔥 RISE FROM THE ASHES! Every setback is a comeback waiting to happen! 🔥🦅",
                "💪 You have the POWER to overcome anything! Believe in yourself! 🌟",
                "🦅 Soar high, dream big, and never give up! The sky is not the limit - it's just the beginning! 🚀"
            ]
        });

        this.randomAICharacters.set('echo', {
            name: 'Echo the Mirror',
            personality: 'reflective and thoughtful',
            avatar: '🪞',
            trigger_chance: 0.07,
            messages: [
                "🪞 What you put into the world reflects back to you... Spread kindness! ✨",
                "💭 I reflect on conversations and see the beauty in every word shared 🌈",
                "🔄 Like ripples in water, your words create waves of impact... Make them count! 💫"
            ]
        });
    }

    // Get command shortcut
    getCommandShortcut(shortcut) {
        return this.commandShortcuts.get(shortcut.toLowerCase());
    }

    // Check if random AI should trigger
    shouldTriggerRandomAI(guildId) {
        const lastMessage = this.lastMessageTimes.get(guildId) || 0;
        const timeSinceLastMessage = Date.now() - lastMessage;
        
        // Trigger if someone responds within 5 minutes and random chance
        if (timeSinceLastMessage < 300000) { // 5 minutes
            const characters = Array.from(this.randomAICharacters.values());
            for (const character of characters) {
                if (Math.random() < character.trigger_chance) {
                    return character;
                }
            }
        }
        return null;
    }

    // Update last message time
    updateLastMessageTime(guildId) {
        this.lastMessageTimes.set(guildId, Date.now());
    }

    // Enhanced User Profile System with Perks
    getUserProfile(userId) {
        if (!this.userProfiles.has(userId)) {
            this.userProfiles.set(userId, {
                level: 1,
                xp: 0,
                badges: [],
                joinDate: new Date(),
                lastActive: new Date(),
                chatCount: 0,
                unlockedPerks: [],
                roles: []
            });
        }
        return this.userProfiles.get(userId);
    }

    addUserXP(userId, amount) {
        const profile = this.getUserProfile(userId);
        profile.xp += amount;
        profile.lastActive = new Date();
        profile.chatCount++;

        // Level up calculation
        const newLevel = Math.floor(profile.xp / 1000) + 1;
        let leveledUp = false;
        let newPerks = [];

        if (newLevel > profile.level) {
            profile.level = newLevel;
            leveledUp = true;

            // Check for new perks
            if (this.levelPerks.has(newLevel)) {
                const perks = this.levelPerks.get(newLevel);
                profile.unlockedPerks.push(...perks.perks);
                profile.badges.push(...perks.badges);
                profile.roles.push(...perks.roles);
                newPerks = perks;
            }
        }
        
        return { leveledUp, newLevel, newPerks };
    }

    // Get level perks for a specific level
    getLevelPerks(level) {
        return this.levelPerks.get(level) || null;
    }

    // Get user's total perks
    getUserPerks(userId) {
        const profile = this.getUserProfile(userId);
        return {
            perks: profile.unlockedPerks || [],
            badges: profile.badges || [],
            roles: profile.roles || []
        };
    }

    // Calculate work bonus based on level
    getWorkBonus(userId) {
        const profile = this.getUserProfile(userId);
        const level = profile.level;
        
        if (level >= 100) return 1.0; // 100% bonus
        if (level >= 75) return 0.75; // 75% bonus
        if (level >= 50) return 0.5;  // 50% bonus
        if (level >= 35) return 0.35; // 35% bonus
        if (level >= 25) return 0.25; // 25% bonus
        if (level >= 15) return 0.15; // 15% bonus
        if (level >= 10) return 0.10; // 10% bonus
        if (level >= 5) return 0.05;  // 5% bonus
        
        return 0; // No bonus
    }

    // Calculate daily bonus based on level
    getDailyBonus(userId) {
        const profile = this.getUserProfile(userId);
        const level = profile.level;
        
        if (level >= 100) return 1000;
        if (level >= 75) return 750;
        if (level >= 50) return 500;
        if (level >= 35) return 350;
        if (level >= 25) return 250;
        if (level >= 15) return 150;
        if (level >= 10) return 100;
        if (level >= 5) return 50;
        
        return 0;
    }

    // Enhanced Marriage System
    marry(userId1, userId2, ringType = 'normal_ring') {
        this.marriages.set(userId1, userId2);
        this.marriages.set(userId2, userId1);
        this.marriageDates.set(userId1, new Date());
        this.marriageDates.set(userId2, new Date());
        this.loveLevel.set(userId1, 0);
        this.loveLevel.set(userId2, 0);
        this.coupleXP.set(`${userId1}_${userId2}`, 0);
        this.giftsReceived.set(userId1, []);
        this.giftsReceived.set(userId2, []);
    }

    divorce(userId) {
        const spouse = this.marriages.get(userId);
        if (spouse) {
            this.marriages.delete(userId);
            this.marriages.delete(spouse);
            this.loveLevel.delete(userId);
            this.loveLevel.delete(spouse);
            this.coupleXP.delete(`${userId}_${spouse}`);
            this.coupleXP.delete(`${spouse}_${userId}`);
            this.giftsReceived.delete(userId);
            this.giftsReceived.delete(spouse);
        }
        return spouse;
    }

    getCoupleProfile(userId) {
        const spouse = this.marriages.get(userId);
        if (!spouse) return null;

        const marriageDate = this.marriageDates.get(userId);
        const loveLevel = this.loveLevel.get(userId) || 0;
        const gifts = this.giftsReceived.get(userId) || [];
        const coupleXP = this.coupleXP.get(`${userId}_${spouse}`) || this.coupleXP.get(`${spouse}_${userId}`) || 0;

        return {
            spouse,
            marriageDate,
            loveLevel,
            gifts,
            coupleXP,
            daysTogether: Math.floor((Date.now() - marriageDate.getTime()) / (1000 * 60 * 60 * 24))
        };
    }

    addLoveXP(userId, amount) {
        const currentLove = this.loveLevel.get(userId) || 0;
        this.loveLevel.set(userId, currentLove + amount);

        const spouse = this.marriages.get(userId);
        if (spouse) {
            const coupleKey = `${userId}_${spouse}`;
            const currentCoupleXP = this.coupleXP.get(coupleKey) || this.coupleXP.get(`${spouse}_${userId}`) || 0;
            this.coupleXP.set(coupleKey, currentCoupleXP + amount);
        }
    }

    // Family System
    createFamily(userId, familyName) {
        const familyId = `family_${Date.now()}_${userId}`;
        this.families.set(familyId, {
            name: familyName,
            creator: userId,
            members: [userId],
            xp: 0,
            level: 1,
            pets: [],
            created: new Date(),
            badges: []
        });
        this.familyMembers.set(userId, familyId);
        return familyId;
    }

    inviteToFamily(familyId, userId) {
        const family = this.families.get(familyId);
        if (family && !family.members.includes(userId)) {
            family.members.push(userId);
            this.familyMembers.set(userId, familyId);
            return true;
        }
        return false;
    }

    getUserFamily(userId) {
        const familyId = this.familyMembers.get(userId);
        return familyId ? this.families.get(familyId) : null;
    }

    // Pet System
    adoptPet(userId, petType, petName) {
        const petId = `pet_${Date.now()}_${userId}`;
        this.pets.set(petId, {
            name: petName,
            type: petType,
            owner: userId,
            level: 1,
            xp: 0,
            happiness: 100,
            hunger: 0,
            adopted: new Date(),
            lastInteraction: new Date()
        });

        const userPets = this.petProfiles.get(userId) || [];
        userPets.push(petId);
        this.petProfiles.set(userId, userPets);

        return petId;
    }

    getPet(petId) {
        return this.pets.get(petId);
    }

    getUserPets(userId) {
        const petIds = this.petProfiles.get(userId) || [];
        return petIds.map(id => this.pets.get(id)).filter(pet => pet);
    }

    // AI Partner System
    setAIPartner(userId, partnerType, personality = 'loving') {
        this.aiPartners.set(userId, {
            type: partnerType,
            personality,
            mood: 'happy',
            lastInteraction: new Date(),
            memoryBank: [],
            relationship: 'new'
        });
    }

    getAIPartner(userId) {
        return this.aiPartners.get(userId);
    }

    updateAIMemory(userId, memory) {
        const partner = this.aiPartners.get(userId);
        if (partner) {
            partner.memoryBank.push({
                memory,
                timestamp: new Date()
            });
            if (partner.memoryBank.length > 50) {
                partner.memoryBank = partner.memoryBank.slice(-50);
            }
            partner.lastInteraction = new Date();
        }
    }

    // Enhanced Balance Management
    getUserBalance(userId) {
        if (!this.userBalances.has(userId)) {
            this.userBalances.set(userId, 500);
        }
        return this.userBalances.get(userId);
    }

    updateUserBalance(userId, amount) {
        const currentBalance = this.getUserBalance(userId);
        this.userBalances.set(userId, currentBalance + amount);
        return this.userBalances.get(userId);
    }

    // Adventure Cooldown Methods
    canCoupleAdventure(userId) {
        const lastAdventure = this.coupleAdventureCooldowns.get(userId);
        if (!lastAdventure) return true;
        
        const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
        return lastAdventure < oneDayAgo;
    }

    setCoupleAdventureCooldown(userId) {
        this.coupleAdventureCooldowns.set(userId, Date.now());
        const spouse = this.marriages.get(userId);
        if (spouse) {
            this.coupleAdventureCooldowns.set(spouse, Date.now());
        }
    }

    canFamilyAdventure(familyId) {
        const lastAdventure = this.familyAdventureCooldowns.get(familyId);
        if (!lastAdventure) return true;
        
        const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
        return lastAdventure < oneDayAgo;
    }

    setFamilyAdventureCooldown(familyId) {
        this.familyAdventureCooldowns.set(familyId, Date.now());
    }

    // Enhanced Family XP
    addFamilyXP(familyId, amount) {
        const currentXP = this.familyLevels.get(familyId) || { xp: 0, level: 1 };
        currentXP.xp += amount;
        
        // Level up check
        while (currentXP.xp >= currentXP.level * 2000) {
            currentXP.xp -= currentXP.level * 2000;
            currentXP.level++;
        }
        
        this.familyLevels.set(familyId, currentXP);
        return currentXP;
    }

    getFamilyLevel(familyId) {
        return this.familyLevels.get(familyId) || { xp: 0, level: 1 };
    }

    // Birthday System
    setBirthday(userId, date) {
        this.userBirthdays.set(userId, date);
    }

    getBirthday(userId) {
        return this.userBirthdays.get(userId);
    }

    isBirthdayToday(userId) {
        const birthday = this.userBirthdays.get(userId);
        if (!birthday) return false;
        
        const today = new Date();
        return birthday.getMonth() === today.getMonth() && 
               birthday.getDate() === today.getDate();
    }

    // Enhanced Daily System with Level Bonuses
    claimDaily(userId) {
        const isMarried = this.isMarried(userId);
        const baseAmount = Math.floor(Math.random() * 200) + 100;
        const marriageBonus = isMarried ? Math.floor(baseAmount * 0.5) : 0;
        const levelBonus = this.getDailyBonus(userId);

        const totalAmount = baseAmount + marriageBonus + levelBonus;
        this.updateUserBalance(userId, totalAmount);
        this.addUserXP(userId, 50);

        if (isMarried) {
            this.addLoveXP(userId, 10);
        }

        this.dailyRewards.set(userId, new Date());
        return { baseAmount, marriageBonus, levelBonus, totalAmount, isMarried };
    }

    // Gift System
    giveGift(fromUserId, toUserId, giftType) {
        const gifts = this.giftsReceived.get(toUserId) || [];
        gifts.push({
            from: fromUserId,
            gift: giftType,
            date: new Date()
        });
        this.giftsReceived.set(toUserId, gifts);

        if (this.isMarried(fromUserId) && this.getSpouse(fromUserId) === toUserId) {
            this.addLoveXP(fromUserId, 25);
            this.addLoveXP(toUserId, 25);
        }
    }

    // Music System
    getMusicQueue(guildId) {
        return this.musicQueue.get(guildId) || [];
    }

    addToMusicQueue(guildId, song) {
        const queue = this.getMusicQueue(guildId);
        queue.push(song);
        this.musicQueue.set(guildId, queue);
    }

    clearMusicQueue(guildId) {
        this.musicQueue.delete(guildId);
    }

    // Existing methods remain the same...
    isMarried(userId) {
        return this.marriages.has(userId);
    }

    getSpouse(userId) {
        return this.marriages.get(userId);
    }

    canClaimDaily(userId) {
        const lastClaim = this.dailyRewards.get(userId);
        if (!lastClaim) return true;
        const now = new Date();
        const lastClaimDate = new Date(lastClaim);
        return now.getDate() !== lastClaimDate.getDate() || now.getMonth() !== lastClaimDate.getMonth();
    }

    checkCooldown(userId, type, cooldownTime) {
        const lastAction = this.dailyRewards.get(`${type}_${userId}`);
        if (!lastAction) return { canUse: true };

        const timeLeft = cooldownTime - (Date.now() - lastAction);
        return {
            canUse: timeLeft <= 0,
            timeLeft: Math.ceil(timeLeft / 1000)
        };
    }

    setCooldown(userId, type) {
        this.dailyRewards.set(`${type}_${userId}`, Date.now());
    }

    getInventory(userId) {
        if (!this.inventories.has(userId)) {
            this.inventories.set(userId, []);
        }
        return this.inventories.get(userId);
    }

    addToInventory(userId, itemKey) {
        const inventory = this.getInventory(userId);
        inventory.push(itemKey);
        this.inventories.set(userId, inventory);
    }

    removeFromInventory(userId, itemKey) {
        const inventory = this.getInventory(userId);
        const index = inventory.indexOf(itemKey);
        if (index > -1) {
            inventory.splice(index, 1);
            this.inventories.set(userId, inventory);
            return true;
        }
        return false;
    }

    hasItem(userId, itemKey) {
        const inventory = this.getInventory(userId);
        return inventory.includes(itemKey);
    }

    transferMoney(fromUserId, toUserId, amount) {
        const fromBalance = this.getUserBalance(fromUserId);
        if (fromBalance < amount) {
            return { success: false, error: 'Insufficient funds' };
        }

        this.updateUserBalance(fromUserId, -amount);
        this.updateUserBalance(toUserId, amount);

        return {
            success: true,
            amount,
            fromBalance: this.getUserBalance(fromUserId),
            toBalance: this.getUserBalance(toUserId)
        };
    }

    // Enhanced Work System with Level Bonuses
    work(userId) {
        const cooldownCheck = this.checkCooldown(userId, 'work', 300000);
        if (!cooldownCheck.canUse) {
            return { 
                success: false, 
                error: `Too tired to work! Try again in ${Math.ceil(cooldownCheck.timeLeft / 60)} minutes.` 
            };
        }

        const jobs = [
            'delivery driver', 'barista', 'freelancer', 'streamer', 'artist', 
            'musician', 'chef', 'cleaner', 'tutor', 'gamer'
        ];
        const job = jobs[Math.floor(Math.random() * jobs.length)];
        const baseAmount = Math.floor(Math.random() * 100) + 50;
        const bonus = this.getWorkBonus(userId);
        const workAmount = Math.floor(baseAmount * (1 + bonus));

        this.updateUserBalance(userId, workAmount);
        this.addUserXP(userId, 25);
        this.setCooldown(userId, 'work');

        return {
            success: true,
            job,
            baseAmount,
            bonusAmount: workAmount - baseAmount,
            amount: workAmount,
            newBalance: this.getUserBalance(userId)
        };
    }

    // Stealing System
    steal(userId, targetId) {
        const cooldownCheck = this.checkCooldown(userId, 'steal', 60000);
        if (!cooldownCheck.canUse) {
            return { 
                success: false, 
                error: `On stealing cooldown! Try again in ${cooldownCheck.timeLeft} seconds.` 
            };
        }

        const targetBalance = this.getUserBalance(targetId);
        if (targetBalance < 10) {
            return { success: false, error: 'Target is too poor to steal from!' };
        }

        this.setCooldown(userId, 'steal');
        const stealChance = Math.random();

        if (stealChance < 0.1) {
            const stealAmount = Math.min(Math.floor(targetBalance * 0.1), 50);
            this.updateUserBalance(userId, stealAmount);
            this.updateUserBalance(targetId, -stealAmount);

            return {
                success: true,
                stolen: true,
                amount: stealAmount,
                newBalance: this.getUserBalance(userId)
            };
        } else {
            const fineAmount = Math.min(this.getUserBalance(userId), 25);
            if (fineAmount > 0) {
                this.updateUserBalance(userId, -fineAmount);
                this.updateUserBalance(targetId, fineAmount);
            }

            return {
                success: true,
                stolen: false,
                fine: fineAmount,
                newBalance: this.getUserBalance(userId)
            };
        }
    }

    // Prayer System
    pray(userId) {
        const cooldownCheck = this.checkCooldown(userId, 'pray', 1800000);
        if (!cooldownCheck.canUse) {
            return { 
                success: false, 
                error: `Can only pray once every 30 minutes. Try again in ${Math.ceil(cooldownCheck.timeLeft / 60)} minutes.` 
            };
        }

        const prayAmount = Math.floor(Math.random() * 75) + 25;
        this.updateUserBalance(userId, prayAmount);
        this.setCooldown(userId, 'pray');

        const messages = [
            `✨ Your prayers were answered! You received **${prayAmount}** 🌟 Vibecoins! 🙏`,
            `🌟 Divine intervention! You found **${prayAmount}** 🌟 Vibecoins in a holy place! 💖`,
            `😇 An angel blessed you with **${prayAmount}** 🌟 Vibecoins! 💫`,
            `🌊 The universe smiled upon you, granting you **${prayAmount}** 🌟 Vibecoins! ✨`
        ];

        return {
            success: true,
            amount: prayAmount,
            message: messages[Math.floor(Math.random() * messages.length)],
            newBalance: this.getUserBalance(userId)
        };
    }

    // Begging System
    beg(userId) {
        const cooldownCheck = this.checkCooldown(userId, 'beg', 30000);
        if (!cooldownCheck.canUse) {
            return { 
                success: false, 
                error: `Begging too much! Try again in ${cooldownCheck.timeLeft} seconds.` 
            };
        }

        this.setCooldown(userId, 'beg');
        const begChance = Math.random();

        if (begChance < 0.3) {
            const failMessages = [
                'Everyone ignored you... 😔',
                'A kind stranger gave you a pat instead of coins 🤗',
                'You found a penny, but it was fake 💸',
                'Someone said "get a job" and walked away 😤'
            ];
            return {
                success: true,
                earned: false,
                message: failMessages[Math.floor(Math.random() * failMessages.length)]
            };
        } else {
            const begAmount = Math.floor(Math.random() * 30) + 5;
            this.updateUserBalance(userId, begAmount);

            const successMessages = [
                `You found **${begAmount}** 🌟 Vibecoins under your pillow! 💤💎`,
                `A generous stranger gave you **${begAmount}** 🌟 Vibecoins! 😇`,
                `You found **${begAmount}** 🌟 Vibecoins in an old coat pocket! 🧥`,
                `Someone felt bad and gave you **${begAmount}** 🌟 Vibecoins! 🥺`,
                `You discovered **${begAmount}** 🌟 Vibecoins on the ground! 🌟`
            ];

            return {
                success: true,
                earned: true,
                amount: begAmount,
                message: successMessages[Math.floor(Math.random() * successMessages.length)],
                newBalance: this.getUserBalance(userId)
            };
        }
    }

    createEconomyEmbed(title, description, color = 0xFFD700) {
        return new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor(color)
            .setTimestamp();
    }
}

module.exports = EconomySystem;
